package day3;

public class operations {
public static void main(String[] args) {
	int a = 12;
	int b = 25;
	int c = 10;
	int d = 50;
	int e = 5;
	int f = 100;
	System.out.println("Enter the first number: "+a);
	System.out.println("Enter the second number: "+b);
	System.out.println();
	System.out.println("Arithmetic Operations:");
	System.out.println("Addition"+(a+b));
	System.out.println("Subtraction"+(a-b));
	System.out.println("Multiplication"+(a*b));
	System.out.println("Division"+(a/b));
	System.out.println("Modulus"+(a%b));
	System.out.println();
	System.out.println("Relational Operations:");
	System.out.println(a+">"+b+":"+(a>b));
	System.out.println(a+"<"+b+":"+(a<b));
	System.out.println(a+">="+b+":"+(a>=b));
	System.out.println(a+"<="+b+":"+(a<=b));
	System.out.println(a+"=="+b+":"+(a==b));
	System.out.println(a+"!="+b+":"+(a!=b));
	System.out.println();
	System.out.println("Logical Operations:");
	System.out.println("("+a+">"+c+"AND"+b+"<"+d+":)"+((a>c)&&(b<d)));
	System.out.println("("+a+"<"+b+"OR"+b+"<"+f+":)"+((a<c)||(b>d)));
	System.out.println("Assignment Operations:");
	System.out.println("Initial Value: "+c);
    System.out.println("After += :"+(c+=12));
    System.out.println("After -= :"+(c-=12));
    System.out.println("After *= :"+(c*=12));
    System.out.println("After /= :"+(c/=12));
    System.out.println("After %= :"+(c%=12));
    System.out.println();
    System.out.println("Unary Oprations:");
    System.out.println("Initial Value :"+a);
    System.out.println("After increment :"+(++a));
    System.out.println("After increment :"+(--a));
	
}
}
