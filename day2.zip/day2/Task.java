package day2;
public class Task {
    public static void main(String[] args) {
        String name1 = "Priya";
        String adjective1 = "nervous";
        String adjective2 = "hectic";
        String noun1 = "students";
        String noun2 = "textbooks";
        String verb1 = "shout";
        String noun3 = "whistles";
        String noun4 = "teachers";
        String adjective3 = "irritated";
        String name2 = "Rahul";
        String place1 = "London";
        String noun5 = "tea";
        int number = 2045;
        String noun6 = "scientists";

        String story = "This morning " + name1 + " woke up feeling " + adjective1 +
                ". 'It is going to be a " + adjective2 + " day!' Outside, a bunch of " +
                noun1 + " were protesting to keep " + noun2 + " in stores. They began to " +
                verb1 + " to the rhythm of the " + noun3 + ", which made all the " + noun4 +
                " very " + adjective3 + ". Concerned, " + name1 + " texted " + name2 +
                ", who flew " + name1 + " to " + place1 + " and dropped " + name1 +
                " in a puddle of frozen " + noun5 + ". " + name1 + " woke up in the year " +
                number + ", in a world where " + noun6 + " ruled the world.";

        System.out.println(story);
    }
}