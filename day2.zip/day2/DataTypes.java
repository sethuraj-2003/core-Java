package day2;

public class DataTypes {
     public static void main(String[] args) {
		byte age = 21;
		System.out.println("byte type is : "+age);
		short a = 130;
		System.out.println("short type is : "+a);
		int EMIS = 23456789;
		System.out.println("int type is : "+EMIS);
		float decimal = 22.314f;
		System.out.println("float type is :+decimal");
		long Phoneno = 6369364066l;
		System.out.println("long type is : "+Phoneno);
		double b = 63.697499498;
		System.out.println("double type is :"+b);
		boolean istrue = false;
		System.out.println("boolean type is :"+istrue);
		char g = 'v';
		System.out.println("name is : "+g);
	}
}
